3D Scene Editor
===============

A 3D editor that allows to prepare 3D scenes composed of multiple3D objects.

